function Leaderboard() {
  const mockData = [
    { name: "Alice", points: 120 },
    { name: "Bob", points: 90 },
    { name: "Charlie", points: 70 },
    { name: "You", points: parseInt(localStorage.getItem("points")) || 0 },
  ];

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🏅 Leaderboard</h2>
      <ul className="space-y-2">
        {mockData.map((user, index) => (
          <li key={index} className="border p-2 rounded">
            #{index + 1} {user.name} — ⭐ {user.points}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Leaderboard;

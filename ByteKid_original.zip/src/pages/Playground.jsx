import { useState, useEffect } from "react";
import Editor from "@monaco-editor/react";

function Playground() {
  const [code, setCode] = useState("console.log('Hello World');");
  const [output, setOutput] = useState("");
  const [currentChallenge, setCurrentChallenge] = useState(0);
  const [completedChallenges, setCompletedChallenges] = useState([]);
  const [points, setPoints] = useState(0);

  const challenges = [
    {
      title: "Hello World",
      description: "Print 'Hello World' to the console",
      starterCode: "console.log('Hello World');",
      testCases: [{ input: "", expected: "Hello World" }],
    },
    {
      title: "Add Two Numbers",
      description: "Write a function add(a, b) that returns a+b",
      starterCode: "function add(a, b) { return a + b; }",
      testCases: [
        { input: "console.log(add(2,3));", expected: "5" },
        { input: "console.log(add(10,15));", expected: "25" },
      ],
    },
  ];

  const challenge = challenges[currentChallenge];

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("completedChallenges")) || [];
    const savedPoints = parseInt(localStorage.getItem("points")) || 0;
    setCompletedChallenges(saved);
    setPoints(savedPoints);
  }, []);

  const runCode = () => {
    let results = [];
    let allPassed = true;

    challenge.testCases.forEach((test, index) => {
      let logs = [];
      const originalLog = console.log;
      console.log = (...args) => logs.push(args.join(" "));

      try {
        eval(code + "\n" + test.input);
      } catch (err) {
        logs.push("Error: " + err.message);
        allPassed = false;
      }

      console.log = originalLog;
      const actual = logs.join("\n").trim();

      if (actual === test.expected) {
        results.push("✅ Test " + (index + 1) + " passed");
      } else {
        results.push("❌ Test " + (index + 1) + " failed → Expected " + test.expected + ", got " + actual);
        allPassed = false;
      }
    });

    if (allPassed && !completedChallenges.includes(currentChallenge)) {
      const updated = [...completedChallenges, currentChallenge];
      setCompletedChallenges(updated);
      localStorage.setItem("completedChallenges", JSON.stringify(updated));
      const newPoints = points + 10;
      setPoints(newPoints);
      localStorage.setItem("points", newPoints);
    }

    setOutput(results.join("\n"));
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">{challenge.title}</h2>
      <p className="mb-4">{challenge.description}</p>

      <Editor
        height="200px"
        defaultLanguage="javascript"
        value={code}
        onChange={(val) => setCode(val || "")}
      />

      <button
        onClick={runCode}
        className="px-4 py-2 bg-green-600 text-white rounded-lg mt-2"
      >
        Run Tests
      </button>

      <pre className="bg-black text-green-400 p-3 rounded mt-2 whitespace-pre-wrap">{output}</pre>
    </div>
  );
}

export default Playground;

function LandingPage() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold mb-4">Welcome to ByteKid 🚀</h1>
      <p className="mb-6">Sharpen your coding skills with interactive challenges!</p>
      <a href="/playground" className="px-6 py-3 bg-blue-600 text-white rounded-lg">
        Start Coding
      </a>
    </div>
  );
}

export default LandingPage;

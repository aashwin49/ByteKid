function Footer() {
  return (
    <footer className="bg-gray-800 text-white text-center p-3 mt-4">
      <p>ByteKid © 2025 - Learn by coding!</p>
    </footer>
  );
}

export default Footer;

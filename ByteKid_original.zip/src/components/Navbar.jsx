function Navbar() {
  const points = localStorage.getItem("points") || 0;

  return (
    <header className="bg-blue-600 text-white p-4 flex justify-between">
      <h1 className="text-xl font-bold">ByteKid</h1>
      <div>⭐ Points: {points}</div>
    </header>
  );
}

export default Navbar;
